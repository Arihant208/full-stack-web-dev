module.exports = {
	preset: "@shelf/jest-mongodb",
	reporters: [ "default", "jest-junit" ]
}